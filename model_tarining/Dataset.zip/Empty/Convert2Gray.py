

# Replace mydir with the directory you want
mydir = '\\intra.tut.fi\home\mahmoodp\My Documents\Desktop\Pattern\Week4\Dataset'
print(type(mydir))
'''
#check if directory exist, if not create it
try:
    os.makedirs(mydir)
except OSError as e:
    if e.errno == errno.EEXIST:
        raise
for fil in glob.glob("*.jpg"):
    image = cv2.imread(fil) 
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) # convert to greyscale
    cv2.imwrite(os.path.join(mydir,fil),gray_image) # write to location with same name
'''


# -*- coding: utf-8 -*-
"""
Created on Thu Jan 24 08:48:51 2019

@author: hehu
"""
'''
import glob

import os

import cv2

def converimg2gray(folder):
      
    subdirectories = glob.glob(folder + "/*")
        
    # Loop over all folders
    for d in subdirectories:
        print(d)
        # Find all files from this folder
        files = glob.glob(d + os.sep + "*.jpg")
                
        # Load all files
        for name in files:
            
            image = cv2.imread(name) 
            print(image.shape)
            gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) # convert to greyscale
            path = mydir + str(subdirectories[0])
            print(path)
            print(gray_image.shape)
            cv2.imwrite(os.path.join(path,'{}'.format(name)),gray_image) # write to location with same name
            



converimg2gray("Dataset")
'''

import cv2
import glob, os, errno

# Replace mydir with the directory you want
mydir = r'\\intra.tut.fi\home\mahmoodp\My Documents\Desktop\Pattern\Week4\Dataset\Empty'
'''
#check if directory exist, if not create it
try:
    os.makedirs(mydir)
except OSError as e:
    if e.errno == errno.EEXIST:
        raise
'''
for fil in glob.glob("*.jpg"):
    image = cv2.imread(fil) 
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) # convert to greyscale
    cv2.imwrite('gray{}'.format(fil),gray_image) # write to location with same name